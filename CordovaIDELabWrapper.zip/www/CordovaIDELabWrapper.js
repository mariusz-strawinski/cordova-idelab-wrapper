var exec = require('cordova/exec');

var PLUGIN_NAME = 'CordovaIDELabWrapper';

var CordovaIDELabWrapper = {
	
	send: function (name, birthday, ) {
		//exec(success, error, 'CordovaIDELabWrapper', 'idelab', [name]);
		alert('TEST');
		}
	
	}


module.exports = CordovaIDELabWrapper;